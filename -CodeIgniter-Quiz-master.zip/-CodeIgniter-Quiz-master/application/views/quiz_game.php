<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Geography Quiz</title>

</head>
<body>

<div id="container">
	<h1>Welcome to Geography Quiz!</h1>


<form method="" action="<?php echo base_url();?>index.php/Questions/quizdisplay">

  <input type="submit" value="Start">
  
 </form> 


</div>

</body>
</html>